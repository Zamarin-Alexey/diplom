"""All tests for label-studio-converter should be written using pytest"""
